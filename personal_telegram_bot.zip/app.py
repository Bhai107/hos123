import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes, CallbackQueryHandler

logging.basicConfig(level=logging.INFO)
TOKEN = os.getenv("BOT_TOKEN")

if not TOKEN:
    raise RuntimeError("BOT_TOKEN secret is missing")

def menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("👤 My Profile", callback_data="profile")],
        [InlineKeyboardButton("📝 Notes", callback_data="notes"),
         InlineKeyboardButton("⚙️ Settings", callback_data="settings")],
        [InlineKeyboardButton("ℹ️ Help", callback_data="help")]
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    name = user.first_name or "Friend"
    await update.message.reply_text(
        f"👋 Welcome, {name}!\n\n"
        "🤖 This is your Personal Telegram Bot.\n"
        "Use the buttons below to get started.",
        reply_markup=menu()
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📌 Commands\n\n"
        "/start — Main menu\n"
        "/help — Help\n"
        "/id — Show your Telegram ID\n\n"
        "More personal features can be added later."
    )

async def user_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        f"🆔 Your Telegram ID: <code>{update.effective_user.id}</code>",
        parse_mode="HTML"
    )

async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "profile":
        u = query.from_user
        username = f"@{u.username}" if u.username else "Not set"
        text = (
            "👤 <b>My Profile</b>\n\n"
            f"Name: {u.full_name}\n"
            f"Username: {username}\n"
            f"ID: <code>{u.id}</code>"
        )
    elif query.data == "notes":
        text = "📝 <b>Notes</b>\n\nNotes feature is ready to be expanded."
    elif query.data == "settings":
        text = "⚙️ <b>Settings</b>\n\nPersonal bot settings will appear here."
    else:
        text = (
            "ℹ️ <b>Help</b>\n\n"
            "This is a personal Telegram bot template. "
            "You can add notes, reminders, file tools, admin tools, or AI features."
        )

    await query.edit_message_text(text, parse_mode="HTML", reply_markup=menu())

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("id", user_id))
    app.add_handler(CallbackQueryHandler(buttons))
    print("🤖 Personal Telegram Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
