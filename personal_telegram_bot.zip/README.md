# Personal Telegram Bot

A simple personal Telegram bot template.

## Replit
1. Create a new Python/Replit project.
2. Upload `app.py`, `requirements.txt`, and `Dockerfile`.
3. Open **Secrets / Environment Variables**.
4. Add:
   - Key: `BOT_TOKEN`
   - Value: your token from BotFather
5. Run the project.

Do not put your real bot token directly inside `app.py`.

## Commands
- `/start`
- `/help`
- `/id`

The inline menu includes Profile, Notes, Settings, and Help.
